# Blood-group-Detection-using-python
Project for detecting blood group using image processing in python
